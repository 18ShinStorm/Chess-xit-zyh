# Zyon Chess Mobile — 1.0

Versão web instalável (PWA) para iPhone/iPad e navegadores móveis. Importa PGN e FEN para revisão de posições e análise local com Stockfish 19 Lite. Não se conecta ao Chess.com nem lê/atua em partidas ao vivo.

## Abrir no iPhone

1. Hospede o conteúdo desta pasta em um servidor HTTPS estático (por exemplo, GitHub Pages ou outro host estático).
2. Abra o endereço no Safari do iPhone.
3. Toque em Compartilhar → Adicionar à Tela de Início → Adicionar.
4. Abra pelo ícone Zyon Chess. Após o primeiro carregamento, os arquivos essenciais ficam disponíveis offline.

No Firefox para iOS, abra o mesmo endereço para usar a versão no navegador. A instalação como app na tela inicial do iPhone é feita pelo Safari/iOS.

## Recursos

- Importação de arquivo PGN ou colagem de PGN.
- Importação de posição FEN.
- Tabuleiro responsivo e navegação lance a lance.
- Análise local Stockfish 19 Lite (4,5 s por posição).
- Avaliação, profundidade, melhor lance e linha principal.
- PWA com cache offline.

## Limitações

- A primeira abertura precisa de internet para baixar os arquivos do site e do motor.
- O motor Lite é usado para manter o download viável em dispositivos móveis; o tempo e a profundidade dependem do aparelho.
- A versão atual é voltada à revisão de partidas concluídas e posições importadas, sem automação de jogadas online.

## Hospedagem

Publique todos os arquivos desta pasta preservando a estrutura. É necessário HTTPS para Service Worker/PWA. O Stockfish WASM deve permanecer ao lado do JavaScript do motor.

## Licenças

Consulte `LICENSE-Stockfish.txt` (GPLv3) e `LICENSE-chess-js.txt` (BSD 2-Clause).
